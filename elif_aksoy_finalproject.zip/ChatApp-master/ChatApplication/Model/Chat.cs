﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ChatApp.Model
{
    public class Chat
    {

        public string UserName
        {
            get;
            set;
        }

        public string UserMessage
        {
            get;
            set;
        }
    }
}
