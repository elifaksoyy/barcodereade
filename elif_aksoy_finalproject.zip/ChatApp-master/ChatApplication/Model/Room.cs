﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ChatApp.Model
{
    public class Room
    {
        public string Name
        {
            get;
            set;
        }

        public string Key
        {
            get;
            set;
        }
    }
}
